/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package club.admin;

import club.business.Member;
import club.data.MemberDB;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author s7kov
 */
public class SKPCMemberAdminController extends HttpServlet {



    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                 HttpSession session = request.getSession();

        String url = " ";
        
        // get current action
        String action = request.getParameter("action");
        
        //Checking if action is empty to prevent errors
        if (action == null) {
            action = "displayMembers";  // default action
        }
        
        // perform action and set URL to appropriate page
        if (action.equals("displayMembers")) {            
            // get list of users
            ArrayList<Member> members = MemberDB.selectMembers();            

            // set as a request attribute
            request.setAttribute("members", members);
            // forward to SKPCDisplayMembers.jsp
            url = "/SKPCDisplayMembers.jsp";
        } 
        else if (action.equals("addMember")) {
            
            //forward to SKPCAddMember.jsp.jsp
            url = "/SKPCAddMember.jsp";
        }
       
        //Finds the existing record and forwards to the SKPCEditMember.jsp.
        else if (action.equals("editMember")) {
            
            
            String email = request.getParameter("email");
            Member memberToUpdate = (Member)MemberDB.selectMember(email);
            request.setAttribute("memberToUpdate", memberToUpdate);
          
            
            url = "/SKPCEditMember.jsp";
        }
        
        //Finds the existing record and forwards to the SKPCRemoveMember.jsp.
        else if (action.equals("removeMember")) {
            
            String email = request.getParameter("email");
            Member memberToDelete = (Member)MemberDB.selectMember(email);
            request.setAttribute("memberToDelete", memberToDelete);
            
            url = "/SKPCRemoveMember.jsp";
        }
        
        
        
        
        getServletContext()
        .getRequestDispatcher(url)
        .forward(request, response);
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String url = "";
        
                
        //Find the existing member and delete from database. Then forwards to Display Members with updated members list
        if (request.getParameter("action").equals("deleteMember")) {
            
            String email = request.getParameter("email");
            Member memberToDelete = (Member)MemberDB.selectMember(email);
            MemberDB.delete(memberToDelete);
            ArrayList<Member> members = MemberDB.selectMembers();            
            request.setAttribute("members", members);
            url = "/SKPCDisplayMembers.jsp";
            
        }
        
        //If action is saveMember call the saveMember method        
        else if (request.getParameter("action").equals("saveMember")) {
            
            url = saveMember(request, response);
                
        }
        
        getServletContext()
        .getRequestDispatcher(url)
        .forward(request, response);
        
       

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
    private String saveMember(HttpServletRequest request, HttpServletResponse response){
        
        String url = " ";
        String message = " ";
        String fullName = request.getParameter("fullName").trim();
        String email = request.getParameter("email").trim();
        String phone = request.getParameter("phone");
        String program = request.getParameter("itProgram");
        String dbOperation = request.getParameter("db_operation");
        int yearLevel = Integer.parseInt(request.getParameter("yearLevel"));        
        
        Member member = new Member(fullName,email);    
        
        //Set default dbOperation to prevent errors if empty
        if (dbOperation == null) {
            dbOperation = "";
        }        
        
        //If its not an update operation then check if member is valid or if email exists.
        if(!dbOperation.equals("update") && (!member.isValid() || MemberDB.emailExists(email)) ){
            message = "Cannot insert a new record, please provide a valid name and/or email";
            url = "/SKPCAddMember.jsp";
            request.setAttribute("message", message);
        }
       
        //Else if the email doesn't exist, insert a new member and updates the members list.
       else if(!MemberDB.emailExists(email)) {
            
            member.setPhoneNumber(phone);
            member.setProgramName(program);
            member.setYearLevel(yearLevel);
            
            MemberDB.insert(member);
            
            ArrayList<Member> members = MemberDB.selectMembers();            
            request.setAttribute("members", members); 
            
            url = "/SKPCDisplayMembers.jsp";
                
        }
       
       //If the operation is an update and the member is not valid show error message.
       else if (dbOperation.equals("update")&& !member.isValid()){
        
            Member memberToUpdate = (Member)MemberDB.selectMember(email);
            message = "Cannot update record, please provide a valid name";
            url = "/SKPCEditMember.jsp";
            request.setAttribute("message", message);
            request.setAttribute("memberToUpdate", memberToUpdate);        
        }
       
       //Else update the member and update the members list. 
         else if(dbOperation.equals("update") && member.isValid()){
        
            Member memberToUpdate = (Member)MemberDB.selectMember(email);
            memberToUpdate.setFullName(fullName);
            memberToUpdate.setPhoneNumber(phone);
            memberToUpdate.setProgramName(program);
            memberToUpdate.setYearLevel(yearLevel);
   
            
            MemberDB.update(memberToUpdate);            
            
            ArrayList<Member> members = MemberDB.selectMembers();            
            request.setAttribute("members", members); 
            url = "/SKPCDisplayMembers.jsp";
        
        }
        
        return url;
        
        }

}
