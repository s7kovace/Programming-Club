/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package club.admin;

import club.business.Book;
import club.data.BookIO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.JspWriter;

/**
 *
 * @author s7kov
 */
public class SKPCAddBookServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
        String url = "/SKPCAddBook.jsp";
        
        String code = request.getParameter("code");
        String description = request.getParameter("description"); 
        String action = request.getParameter("action");
        
        ServletContext context = getServletContext();
        String path = context.getRealPath("/WEB-INF/books.txt");
        
        int quantity;
        
        if (request.getParameter("quantity") == null || request.getParameter("quantity").isEmpty()) {
            
            quantity = 0;
            
        }
        else{
              
            quantity = Integer.parseInt(request.getParameter("quantity"));
        
        }
        
        
        Book book = new Book(code, description, quantity);
       
        ArrayList<String> messages = new ArrayList();
        //String message = "";
        
        if (code == null || code.isEmpty()) {
            
            //message += "Book code is required " + "\n";
            messages.add("Book code is required");
            
        }
        if (description.length() < 3) {
            
            //message += "Description must have at least 3 characters \n";
            messages.add("Description must have at least 3 characters");
        }
        
        if (quantity <= 0) {
            
            //message += "Quantity must be a positive number";
            messages.add("Quantity must be a positive number");
            
        }
        
        if (messages.isEmpty()) {
        //Instance of Book Class
            book = new Book(code, description, quantity);
            BookIO.insert(book, path);
            url = "/SKPCDisplayBooks";

        }
        else{
            
            url = "/SKPCAddBook.jsp";
        

        }
        
        request.setAttribute("messages", messages);
        request.setAttribute("book", book);


        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);

        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
