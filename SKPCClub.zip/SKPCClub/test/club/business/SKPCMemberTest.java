/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package club.business;

import java.util.Set;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author s7kov
 */
public class SKPCMemberTest {
    
    public SKPCMemberTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getFullName method, of class Member.
     */
    @Test
    public void testGetFullName() {
        System.out.println("getFullName");
        Member instance = new Member("Patricia"," ");
        String expResult = "Patricia";
        String result = instance.getFullName();
        assertEquals(expResult, result);

    }

    /**
     * Test of setFullName method, of class Member.
     */
    @Test
    public void testSetFullName() {
        System.out.println("setFullName");
        String fullName = "Bobby";
        Member instance = new Member();
        instance.setFullName(fullName);
        String expResult = "Bobby";
        String result = instance.getFullName();
        assertEquals(expResult, result);

    }

    /**
     * Test of getEmailAddress method, of class Member.
     */
    @Test
    public void testGetEmailAddress() {
        System.out.println("getEmailAddress");
        Member instance = new Member("","abc@gmail.com");
        String expResult = "abc@gmail.com";
        String result = instance.getEmailAddress();
        assertEquals(expResult, result);

    }

    /**
     * Test of setEmailAddress method, of class Member.
     */
    @Test
    public void testSetEmailAddress() {
        System.out.println("setEmailAddress");
        String emailAddress = "abc@gmail.com";
        Member instance = new Member();
        instance.setEmailAddress(emailAddress);
        String expResult = "abc@gmail.com";
        String result = instance.getEmailAddress();
        assertEquals(expResult, result);

    }

    /**
     * Test of getPhoneNumber method, of class Member.
     */
    @Test
    public void testGetPhoneNumber() {
        System.out.println("getPhoneNumber");
        String phoneNumber = null;
        Member instance = new Member();
        instance.setPhoneNumber(phoneNumber);    
        String expResult = "";
        String result = instance.getPhoneNumber();
        assertEquals(expResult, result);

    }

    /**
     * Test of setPhoneNumber method, of class Member.
     */
    @Test
    public void testSetPhoneNumber() {
        System.out.println("setPhoneNumber");
        String phoneNumber = "519-888-9999";
        Member instance = new Member();
        instance.setPhoneNumber(phoneNumber);
        String expResult = "519-888-9999";
        String result = instance.getPhoneNumber();
        assertEquals(expResult, result);

    }

    /**
     * Test of getProgramName method, of class Member.
     */
    @Test
    public void testGetProgramName() {
        System.out.println("getProgramName");
        String programName = null;
        Member instance = new Member();
        String expResult = "";
        String result = instance.getProgramName();
        assertEquals(expResult, result);
    }

    /**
     * Test of setProgramName method, of class Member.
     */
    @Test
    public void testSetProgramName() {
        System.out.println("setProgramName");
        String programName = "CPA";
        Member instance = new Member();
        instance.setProgramName(programName);
        String expResult = "CPA";
        String result = instance.getProgramName();
        assertEquals(expResult, result);

    }

    /**
     * Test of getYearLevel method, of class Member.
     */
    @Test
    public void testGetYearLevel() {
        System.out.println("getYearLevel");
        Member instance = new Member();
        int expResult = 0;
        int result = instance.getYearLevel();
        assertEquals(expResult, result);

    }

    /**
     * Test of setYearLevel method, of class Member.
     */
    @Test
    public void testSetYearLevel() {
        System.out.println("setYearLevel");
        int yearLevel = 4;
        Member instance = new Member();
        instance.setYearLevel(yearLevel);
        int expResult = 4;
        int result = instance.getYearLevel();
        assertEquals(expResult, result);

    }

    /**
     * Test of isValid method, of class Member.
     */
    @Test
    public void testValidPositive() {
        System.out.println("isValid");
        Member instance = new Member("Monica","abcd@hotmail.com");
        boolean expResult = true;
        boolean result = instance.isValid();
        assertEquals(expResult, result);
 
    }
        @Test
    public void testValidNegative() {
        System.out.println("isValid");
        Member instance = new Member();
        boolean expResult = false;
        boolean result = instance.isValid();
        assertEquals(expResult, result);
 
    }
    
}
